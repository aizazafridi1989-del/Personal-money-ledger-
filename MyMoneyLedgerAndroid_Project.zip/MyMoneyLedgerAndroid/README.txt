MY MONEY LEDGER — ANDROID APP PROJECT

This is the Android Studio source project for the My Money Ledger app. It includes the updated money-count section on the first screen.

WHAT THE APP DOES
- Records cash spent/received, Easypaisa spent/received, and transfers between them.
- Separates Restaurant, Personal, and Shared transactions.
- Lets you enter today's actual cash and Easypaisa balances on the home screen and compare them to the ledger.
- Keeps transaction history, daily closing checks, CSV export, and JSON backup/restore.
- Stores data locally on this Android device; it does not sync to other devices automatically.

IMPORTANT ABOUT THE APK
The APK has not been compiled in this environment because Android SDK/build tools are not installed here. Do not rename the ZIP to .apk; that will not work.

BUILD THE APK
Option A: Android Studio
1. Extract this folder.
2. Open the MyMoneyLedger folder in Android Studio.
3. Let Gradle sync and install Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is usually created at app/build/outputs/apk/debug/app-debug.apk.

Option B: GitHub Actions
1. Upload the contents of this project folder to a new GitHub repository on the main branch.
2. Open the repository's Actions tab and run “Build Android APK” (or wait for the first push build).
3. Open the successful workflow run and download the “MyMoneyLedger-debug-apk” artifact.
4. Extract the artifact ZIP on your phone/computer; install app-debug.apk on Android. Android may ask you to allow installation from that source.

A debug APK is for personal installation/testing, not Play Store release signing.

DATA SAFETY
Records are stored in app-local browser storage on the device. Use History > Backup data regularly and keep a copy somewhere safe. Clearing app data or uninstalling may erase records if you have no backup.
